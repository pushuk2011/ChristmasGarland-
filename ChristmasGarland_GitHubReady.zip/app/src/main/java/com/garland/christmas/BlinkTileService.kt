package com.garland.christmas
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class BlinkTileService : TileService() {
    override fun onStartListening() = refresh()
    override fun onClick() {
        Prefs.setBlink(this, !Prefs.blink(this)); refresh()
        if (Prefs.garland(this) && GarlandService.inst == null) try { GarlandService.start(this) } catch (_: Exception) {}
    }
    private fun refresh() {
        val t = qsTile ?: return
        t.label = "БЛИМАННЯ"; t.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        t.state = if (Prefs.blink(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
