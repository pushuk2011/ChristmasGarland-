package com.garland.christmas
import android.app.*
import android.content.*
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*

class GarlandService : Service() {
    companion object {
        @Volatile var inst: GarlandService? = null
        fun start(c: Context) { c.startForegroundService(Intent(c, GarlandService::class.java)) }
        fun stop(c: Context) { c.stopService(Intent(c, GarlandService::class.java)) }
    }
    private lateinit var wm: WindowManager
    private var view: GarlandView? = null
    private var landscape = false
    private var shade = false
    private val l = SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "blink") view?.blinking = Prefs.blink(this)
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("g", "Гірлянда", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "g").setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Christmas Garland працює").setContentIntent(pi).build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        inst = this
        wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, (84 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP; lp.y = sb - (6 * d).toInt()
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        view = GarlandView(this).also { it.blinking = Prefs.blink(this); wm.addView(it, lp) }
        refresh()
        Prefs.listen(this, l)
    }
    private fun refresh() { view?.visibility = if (landscape || shade) View.INVISIBLE else View.VISIBLE }
    fun setShade(v: Boolean) { if (shade != v) { shade = v; refresh() } }
    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        landscape = c.orientation == Configuration.ORIENTATION_LANDSCAPE; refresh()
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        Prefs.unlisten(this, l)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        inst = null; super.onDestroy()
    }
}
