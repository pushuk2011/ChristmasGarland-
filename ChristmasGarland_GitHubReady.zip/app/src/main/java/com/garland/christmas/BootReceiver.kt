package com.garland.christmas
import android.content.*
import android.provider.Settings
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.garland(c) && Settings.canDrawOverlays(c)) try { GarlandService.start(c) } catch (_: Exception) {}
    }
}
