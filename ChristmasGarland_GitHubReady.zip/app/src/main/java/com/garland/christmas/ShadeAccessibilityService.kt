package com.garland.christmas
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ShadeAccessibilityService : AccessibilityService() {
    private val ui = setOf("com.android.systemui", "miui.systemui.plugin")
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
        if (pkg != null) GarlandService.inst?.setShade(pkg in ui)
    }
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean { GarlandService.inst?.setShade(false); return super.onUnbind(i) }
}
