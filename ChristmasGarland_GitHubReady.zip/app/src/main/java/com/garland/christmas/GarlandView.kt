package com.garland.christmas
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.atan2

class GarlandView(c: Context) : View(c) {
    private val d = resources.displayMetrics.density
    private val cols = intArrayOf(0xFFE53935.toInt(), 0xFF43A047.toInt(), 0xFFFFC107.toInt())
    private val wire = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF151515.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sock = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2B2B2B.toInt() }
    private val path = Path()
    private val oval = RectF()
    private val t0 = SystemClock.uptimeMillis()
    private val stepMs = 650L
    var blinking = false
        set(v) { field = v; invalidate() }

    private fun lerp(a: Int, b: Int, f: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt())

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val top = 6f * d; val sag = 26f * d
        path.reset(); path.moveTo(0f, top); path.quadTo(w / 2, top + 2 * sag, w, top)
        cv.drawPath(path, wire)
        var s = 0; var e = 0f
        if (blinking) {
            val ph = ((SystemClock.uptimeMillis() - t0) % (stepMs * 3)) / stepMs.toFloat()
            s = ph.toInt(); val f = ph - s
            e = ((f - 0.25f) / 0.5f).coerceIn(0f, 1f).let { it * it * (3 - 2 * it) }
        }
        val n = (w / (34f * d)).toInt().coerceAtLeast(4)
        for (i in 0 until n) {
            val t = (i + 0.5f) / n
            val x = w * t; val y = top + 4 * sag * t * (1 - t)
            val ang = Math.toDegrees(atan2(4 * sag * (1 - 2 * t), w).toDouble()).toFloat()
            val col = lerp(cols[(i + s) % 3], cols[(i + s + 1) % 3], e)
            cv.save(); cv.translate(x, y); cv.rotate(ang)
            fill.color = col
            for ((r, a) in arrayOf(17f to 22, 13f to 40, 9f to 70)) {
                fill.alpha = a; cv.drawCircle(0f, 15f * d, r * d, fill)
            }
            cv.drawRect(-2.5f * d, 0f, 2.5f * d, 6f * d, sock)
            fill.color = col; fill.alpha = 255
            oval.set(-5f * d, 5f * d, 5f * d, 22f * d); cv.drawOval(oval, fill)
            fill.color = Color.WHITE; fill.alpha = 110
            cv.drawCircle(-1.8f * d, 11f * d, 1.6f * d, fill)
            cv.restore()
        }
        if (blinking) postInvalidateDelayed(33)
    }
}
