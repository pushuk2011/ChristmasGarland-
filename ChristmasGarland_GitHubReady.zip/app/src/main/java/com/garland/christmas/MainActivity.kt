package com.garland.christmas
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var btn: Button
    private lateinit var sw: Switch
    private lateinit var acc: TextView
    private lateinit var preview: GarlandView
    private val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> runOnUiThread { sync() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sz: Float, col: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col); setPadding(0, dp(8), 0, dp(8)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF0B1B2B.toInt(); window.navigationBarColor = 0xFF0B1B2B.toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0B1B2B.toInt()); setPadding(dp(20), dp(24), dp(20), dp(20)) }
        root.addView(tv("🎄 Christmas Garland", 26f).apply { gravity = Gravity.CENTER })
        preview = GarlandView(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(84)))
        status = tv("", 16f, 0xFFFFC107.toInt()); root.addView(status)
        btn = Button(this); btn.setOnClickListener { toggle() }; root.addView(btn)
        sw = Switch(this).apply { text = "Блимання"; textSize = 18f; setTextColor(Color.WHITE); setPadding(0, dp(12), 0, dp(12))
            setOnCheckedChangeListener { v, on -> if (v.isPressed) Prefs.setBlink(this@MainActivity, on) } }
        root.addView(sw)
        root.addView(tv("Дозволи:\n1) «Поверх інших програм» — обов'язково.\n2) Спеціальні можливості (необов'язково) — лише щоб ховати гірлянду, коли відкрита шторка.\n3) MIUI: Налаштування → Додатки → Christmas Garland → Автозапуск УВІМК., Заощадження заряду «Без обмежень».\n4) Плитку «БЛИМАННЯ» додайте у шторці кнопкою редагування (олівець).", 13f, 0xFFB0BEC5.toInt()))
        acc = tv("", 14f); root.addView(acc)
        root.addView(Button(this).apply { text = "Увімкнути приховування під шторкою"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B1B2B.toInt()); addView(root) })
    }
    private fun toggle() {
        if (Prefs.garland(this)) { Prefs.setGarland(this, false); GarlandService.stop(this) }
        else if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        else { Prefs.setGarland(this, true); GarlandService.start(this) }
        sync()
    }
    private fun sync() {
        val on = Prefs.garland(this)
        btn.text = if (on) "Вимкнути гірлянду" else "Увімкнути гірлянду"
        status.text = "Статус: " + (if (on) "гірлянда працює" else "вимкнена") + (if (Settings.canDrawOverlays(this)) "" else " • немає дозволу «Поверх інших програм»")
        sw.isChecked = Prefs.blink(this); preview.blinking = Prefs.blink(this)
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        acc.text = "Приховування під шторкою: " + (if (en.contains(packageName)) "увімкнено" else "вимкнено")
    }
    override fun onResume() { super.onResume(); Prefs.listen(this, l); sync() }
    override fun onPause() { Prefs.unlisten(this, l); super.onPause() }
}
