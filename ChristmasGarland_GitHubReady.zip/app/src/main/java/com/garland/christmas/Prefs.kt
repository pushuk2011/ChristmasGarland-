package com.garland.christmas
import android.content.Context
import android.content.SharedPreferences
object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("garland", Context.MODE_PRIVATE)
    fun garland(c: Context) = sp(c).getBoolean("garland", false)
    fun blink(c: Context) = sp(c).getBoolean("blink", false)
    fun setGarland(c: Context, v: Boolean) = sp(c).edit().putBoolean("garland", v).apply()
    fun setBlink(c: Context, v: Boolean) = sp(c).edit().putBoolean("blink", v).apply()
    fun listen(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) = sp(c).registerOnSharedPreferenceChangeListener(l)
    fun unlisten(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) = sp(c).unregisterOnSharedPreferenceChangeListener(l)
}
